from django.contrib import messages
from django.contrib.auth.models import User
from django.shortcuts import redirect, render
from django.contrib.auth import authenticate,login,logout
from django.contrib.auth.decorators import login_required
# Create your views here.

def login_page(request):
        if request.method=='POST':
            username=request.POST.get('username')
            pass1=request.POST.get('pass')
            user=authenticate(request,username=username,password=pass1)
            if user is not None:
                 login(request,user)
                 return redirect('home')
            else:
                 messages.error(request, "Invalid username or password")
        return render(request, 'login.html')

@login_required(login_url='login')
def home(request):
    return render(request, 'home.html')

def SignuPage(request):
        if request.method=='POST':
           uname=request.POST.get('username')
           email=request.POST.get('email')
           pass1=request.POST.get('password1')
           pass2=request.POST.get('password2')

           if pass1!=pass2:
              messages.error(request, "Password's are not match")
              return redirect('signup')
           if User.objects.filter(username=uname).exists():
              messages.error(request, "Username already exists")
              return redirect('signup')
           if User.objects.filter(email=email).exists():
              messages.error(request, "Email already registered")
              return redirect('signup')
           else:
               my_user=User.objects.create_user(uname,email,pass1)
               my_user.save()
               return redirect('login')

        return render(request, 'signup.html')
def LogoutPage(request):
     logout(request)
     return redirect('login')

def bmi(request):
    context = {"progress": 0}
    if request.method == "POST":
        age = request.POST.get("age")
        gender = request.POST.get("gender")
        weight = request.POST.get("weight")
        height = request.POST.get("height")

        if age and weight and height:
            age = int(age)
            weight = float(weight)
            height = float(height) / 100

            bmi = round(weight / (height * height), 2)

            if bmi < 18.5:
                status = "Underweight"
                progress = 25

            elif bmi < 25:
                status = "Normal"
                progress = 50

            elif bmi < 30:
                status = "Overweight"
                progress = 75

            else:
                status = "Obese"
                progress = 100

            context = {
                "bmi": bmi,
                "status": status,
                "progress": progress,
                "age": age,
                "gender": gender
            }
            if status == "Underweight":
                  return render(request, "Underweight.html",context)
            if status == "Overweight":
                  return render(request, "Overweight.html",context)
            if status == "Normal":
                  return render(request, "Normal.html",context)
            if status == "Obese":
                  return render(request, "Obese.html",context)
    return render(request, "BMI.html", context)

def About(request):
     return render(request, 'about.html')
def Excercise(request):
     return render(request, 'Exercise.html')
def help(request):
     return render(request, 'help.html')
def Faq(request):
     return render(request, 'Faq.html')
def Terms(request):
     return render(request, 'Terms.html')
def Feedback(request):
     return render(request, 'Feedback.html')