from django.contrib import admin
from django.urls import path
from . import views

urlpatterns = [
    path('home/', views.home, name='home'),
    path('about/', views.About, name='about'),
    path('Exercise/', views.Excercise, name='Exercise'),
    path('', views.SignuPage, name='signup'),
    path('signup/', views.SignuPage, name='signup'),
    path('login/', views.login_page, name='login'),
    path('logout/', views.LogoutPage, name='logout'),
    path('BMI/', views.bmi, name='BMI'),
    path('help/', views.help, name='help'),
    path('Faq/', views.Faq, name='Faq'),
    path('Terms/', views.Terms, name='Terms'),
    path('Feedback/', views.Feedback, name='Feedback'),
]
